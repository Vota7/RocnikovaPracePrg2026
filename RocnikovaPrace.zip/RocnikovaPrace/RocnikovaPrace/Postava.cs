﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static RocnikovaPrace.Skill;
namespace RocnikovaPrace
{
    public class Postava
    {
        public string Name { get; set; }
        public int MaxHeart { get; set; }
        public int Heart { get; set; }
        public int MaxJuice { get; set; }
        public int Juice { get; set; }
        public int Attack { get; set; }
        public int Defense { get; set; }
        public int Speed { get; set; }
        public int Luck { get; set; }
        public int Hit { get; set; }
        public string Emotion { get; set; }
        public bool ActFirst { get; set; }
        public string Type { get; set; }
        
        public Postava(string name, int maxHeart, int attack, int defense, int speed, int luck, int hit, string type, int maxJuice = 0)
        {
            Name = name;
            MaxHeart = maxHeart;
            Heart = maxHeart;
            MaxJuice = maxJuice;
            Juice = maxJuice;
            Attack = attack;
            Defense = defense;
            Speed = speed;
            Luck = luck;
            Hit = hit;
            Emotion = "";
            Type = "";
        }
    }

    public class Team : Postava
    {
        
        public List<Skill> EquipedSkills = new() { };

        public Team(string name, int maxHeart, int maxJuice, int attack, int defense, int speed, int luck, int hit, string type) : base(name, maxHeart, attack, defense, speed, luck, hit, type, maxJuice)
        {
            ActFirst = false;
        }

        public static Team Omori = new Team("Omori", 10, 10, 10, 10, 10, 10, 10, "Team");
        public static Team Kel = new Team("Kel", 10, 10, 10, 10, 10, 10, 10, "Team");
        public static Team Aubrey = new Team("Aubrey", 10, 10, 10, 10, 10, 10, 10, "Team");
        public static Team Hero = new Team("Hero", 10, 10, 10, 10, 10, 10, 10, "Team");

        public static List<Postava> TeamList = new() { Omori, Kel, Aubrey, Hero };

        

    }

    public class Enemy : Postava
    {
        public Enemy(string name, int maxHeart, int maxJuice, int attack, int defense, int speed, int luck, int hit, string type) : base(name, maxHeart, attack, defense, speed, luck, hit, type, maxJuice)
        {

        }

        public static Enemy SproutMole = new Enemy("Sprout Mole", 10, 99999999, 10, 10, 10, 10, 10, "Enemy");
    }
}