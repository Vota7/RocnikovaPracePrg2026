﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RocnikovaPrace
{
    public class Skill
    {
        public string Name { get; set; }
        public int Cost { get; set; }
        public string Description { get; set; }

        public Skill(string name, int cost, string description)
        {
            Name = name;
            Cost = cost;
            Description = description;
        }

        protected void PlayerAttackEnemy(BattleContext context)
        {
            context.Target.Heart -= context.User.Attack * 2 - context.Target.Defense;
            MessageBox.Show(context.Target.Heart.ToString());
        }

        public virtual void Use(BattleContext context)
        {

        }
    }

    public class AttackEnemy : Skill
    {
        public AttackEnemy AttackSkill = new AttackEnemy("Attack", 0, "NG", 10);

        public AttackEnemy(string name, int cost, string description, int damage) :base(name, cost, description) 
        {
            Damage = damage;
        }

        public int Damage { get; set; }

        public override void Use(BattleContext context)
        {
            context.User.Juice -= Cost;
            PlayerAttackEnemy(context);
        }
    }
}
