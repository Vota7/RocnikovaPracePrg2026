﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RocnikovaPrace
{
    public class BattleContext
    {
        public Postava User {  get; set; }
        public Postava Target { get; set; }
    }
}
