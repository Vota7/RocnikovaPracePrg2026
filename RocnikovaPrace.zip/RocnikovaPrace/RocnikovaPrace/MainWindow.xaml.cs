﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static RocnikovaPrace.Team;
using static RocnikovaPrace.Enemy;
using static RocnikovaPrace.AttackEnemy;
using System.Windows.Controls.Primitives;

namespace RocnikovaPrace
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            BattleContext context = new BattleContext
            {
                User = Omori,
                Target = SproutMole
            };
            Omori.EquipedSkills.Add(AttackSkill);
            Omori.EquipedSkills[0].Use(context);
        }

        public void Turn()
        {
            Sort();
        }

        public void Sort()
        {
            foreach (var postava in TeamList)
            {

            }
        }
    }
}